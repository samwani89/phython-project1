a = int(input("Enter a number: "))

if a > 0:
    print(a, "is a positive number")
elif a < 0:
    print(a, "is a negative number")
else:
    print("The number is zero")
