a = int(input("Enter the first number: "))
b = int(input("Enter the second number: "))

if(a > b):
    print(a , "is greater than" , b)
else:
    print(b , "is greater than" , a)