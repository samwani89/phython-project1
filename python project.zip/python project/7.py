char = input("Enter a character: ")

# The isalpha() method checks whether the input is an alphabetic character

if char.isalpha():
    print(char, "is an alphabet")
else:
    print(char, "is not an alphabet")
