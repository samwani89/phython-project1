a = int(input("Enter the number:"))

if (a % 2 == 1):
    print(a , "is odd!")
else:
    print(a , "is even!")