month = int(input("Enter the month number (1-12): "))

if month == 1:  # January
    print("January has 31 days.")
elif month == 2:  # February
    print("February has 28 days (29 days in a leap year).")
elif month == 3:  # March
    print("March has 31 days.")
elif month == 4:  # April
    print("April has 30 days.")
elif month == 5:  # May
    print("May has 31 days.")
elif month == 6:  # June
    print("June has 30 days.")
elif month == 7:  # July
    print("July has 31 days.")
elif month == 8:  # August
    print("August has 31 days.")
elif month == 9:  # September
    print("September has 30 days.")
elif month == 10:  # October
    print("October has 31 days.")
elif month == 11:  # November
    print("November has 30 days.")
elif month == 12:  # December
    print("December has 31 days.")
else:
    print("Invalid month number. Please enter a number between 1 and 12.")
