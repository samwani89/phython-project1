week_number = int(input("Enter the week number (1-7): "))

if week_number == 1:
    print("Monday")
elif week_number == 2:
    print("Tuesday")
elif week_number == 3:
    print("Wednesday")
elif week_number == 4:
    print("Thursday")
elif week_number == 5:
    print("Friday")
elif week_number == 6:
    print("Saturday")
elif week_number == 7:
    print("Sunday")
else:
    print("Invalid week number. Please enter a number between 1 and 7.")
