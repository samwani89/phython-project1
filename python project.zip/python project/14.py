x = float(input("Enter the first angle: "))
y = float(input("Enter the second angle: "))
z = float(input("Enter the third angle: "))

if x + y + z == 180:
    print("The triangle is valid.")
else:
    print("The triangle is not valid.")
